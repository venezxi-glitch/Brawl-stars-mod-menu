package com.ritmada.menu;

import java.util.Arrays;
import java.util.Collections;

public class MathCheck {
    static void check(String name, boolean ok) { System.out.println((ok ? "PASS " : "FAIL ") + name); if (!ok) System.exit(1); }

    public static void main(String[] a) {
        // Head-on threat from +x: dodge must be perpendicular (x ~ 0).
        GameSnapshot s1 = new GameSnapshot(0, 0, 1, Arrays.asList(new GameSnapshot.Threat(10, 0, -5, 0, 1)));
        float[] d1 = DodgeMath.dodgeDirection(s1, 0.6f * 10, 0.25f);
        check("head-on gives perpendicular dodge", d1 != null && Math.abs(d1[0]) < 1e-4 && Math.abs(Math.abs(d1[1]) - 1) < 1e-4);

        // Path passes with threat on +y side: dodge must move toward -y (away).
        GameSnapshot s2 = new GameSnapshot(0, 0, 1, Arrays.asList(new GameSnapshot.Threat(10, 1, -5, 0, 1)));
        float[] d2 = DodgeMath.dodgeDirection(s2, 6f, 0.25f);
        check("offset path dodges away from path", d2 != null && d2[1] < -0.99f);

        // Path far away: no dodge.
        GameSnapshot s3 = new GameSnapshot(0, 0, 1, Arrays.asList(new GameSnapshot.Threat(10, 10, -5, 0, 1)));
        check("distant path gives null", DodgeMath.dodgeDirection(s3, 6f, 0.25f) == null);

        // No threats and NaN input.
        check("no threats gives null", DodgeMath.dodgeDirection(new GameSnapshot(0, 0, 1, Collections.<GameSnapshot.Threat>emptyList()), 6f, 0.25f) == null);
        GameSnapshot s4 = new GameSnapshot(0, 0, 1, Arrays.asList(new GameSnapshot.Threat(Float.NaN, 0, 1, 0, 1)));
        check("NaN threat ignored", DodgeMath.dodgeDirection(s4, 6f, 0.25f) == null);

        // Stationary hazard overlapping on +x: push toward -x.
        GameSnapshot s5 = new GameSnapshot(0, 0, 1, Arrays.asList(new GameSnapshot.Threat(1, 0, 0, 0, 1)));
        float[] d5 = DodgeMath.dodgeDirection(s5, 6f, 0.25f);
        check("stationary hazard pushes away", d5 != null && d5[0] < -0.99f);

        // Circle points.
        float[] p = JoystickMath.pointOnCircle(100, 200, 50, Math.PI / 2);
        check("pointOnCircle at 90deg (y down)", Math.abs(p[0] - 100) < 1e-3 && Math.abs(p[1] - 250) < 1e-3);
    }
}
