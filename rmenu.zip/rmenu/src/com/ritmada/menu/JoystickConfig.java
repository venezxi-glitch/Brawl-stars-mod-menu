package com.ritmada.menu;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.DisplayMetrics;

/** Joystick geometry in decor-view pixels. NaN means unset (distinct from a real 0). */
final class JoystickConfig {
    private static final String PREFS = "ritmada_menu";

    float anchorX = Float.NaN, anchorY = Float.NaN, radius = Float.NaN;

    static boolean finite(float v) { return !Float.isNaN(v) && !Float.isInfinite(v); }

    boolean isSet() { return finite(anchorX) && finite(anchorY) && finite(radius) && radius >= 20f; }

    void load(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        if (!p.contains("ax") || p.getInt("w", -1) != dm.widthPixels || p.getInt("h", -1) != dm.heightPixels) return;
        anchorX = p.getFloat("ax", Float.NaN);
        anchorY = p.getFloat("ay", Float.NaN);
        radius = p.getFloat("r", Float.NaN);
        if (!isSet()) { anchorX = anchorY = radius = Float.NaN; }
    }

    void save(Context c) {
        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putFloat("ax", anchorX).putFloat("ay", anchorY).putFloat("r", radius)
            .putInt("w", dm.widthPixels).putInt("h", dm.heightPixels).apply();
    }
}
