package com.ritmada.menu;

/** Marks the unknown: no game-state source has been provided yet. Auto Dodge stays gated. */
final class UnconfiguredThreatSource implements ThreatSource {
    @Override public boolean isAvailable() { return false; }
    @Override public String unavailableReason() {
        return "No game-state source set. Provide a ThreatSource via ModMenu.setThreatSource().";
    }
    @Override public GameSnapshot poll() { return null; }
}
