package com.ritmada.menu;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

/**
 * Full-screen capture. The player touches where the game's movement joystick should be pressed
 * and drags out to its full-tilt distance. DOWN point = anchor, farthest drag distance = radius.
 */
final class CalibrationOverlay extends View {
    interface Listener {
        void onDone(float anchorX, float anchorY, float radius);
        void onCancel();
    }

    private final Listener listener;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float ax = Float.NaN, ay = Float.NaN, maxDist;

    CalibrationOverlay(Context c, Listener l) {
        super(c);
        listener = l;
        paint.setTextSize(42f);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getPointerCount() > 1) return true;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                ax = e.getX(); ay = e.getY(); maxDist = 0; invalidate(); return true;
            case MotionEvent.ACTION_MOVE:
                maxDist = Math.max(maxDist, (float) Math.hypot(e.getX() - ax, e.getY() - ay));
                invalidate(); return true;
            case MotionEvent.ACTION_UP:
                if (maxDist >= 20f) listener.onDone(ax, ay, maxDist); else listener.onCancel();
                return true;
            case MotionEvent.ACTION_CANCEL:
                listener.onCancel(); return true;
            default: return true;
        }
    }

    @Override protected void onDraw(Canvas c) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0x88000000);
        c.drawRect(0, 0, getWidth(), getHeight(), paint);
        paint.setColor(0xFFFFFFFF);
        c.drawText("Calibrate: press where the move joystick is, drag to full tilt, release.", 40f, 80f, paint);
        if (JoystickConfig.finite(ax)) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(4f);
            paint.setColor(0xFF00E5FF);
            c.drawCircle(ax, ay, Math.max(maxDist, 8f), paint);
        }
    }
}
