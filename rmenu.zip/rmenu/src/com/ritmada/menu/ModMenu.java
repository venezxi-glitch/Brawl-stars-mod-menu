package com.ritmada.menu;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/** Entry point: ModMenu.attach(activity) from the game's launcher Activity.onCreate. */
public final class ModMenu {
    private static ModMenu instance;
    private static volatile ThreatSource pendingSource;

    public static void attach(final Activity activity) {
        final View decor = activity.getWindow().getDecorView();
        decor.post(new Runnable() {
            @Override public void run() {
                if (!(decor instanceof ViewGroup)) return;
                if (instance != null) {
                    if (instance.activity == activity) return;
                    instance.detach();
                }
                instance = new ModMenu(activity, (ViewGroup) decor);
                instance.build();
            }
        });
    }

    public static void setThreatSource(ThreatSource s) {
        pendingSource = s;
        if (instance != null) instance.dodge.setSource(s);
    }

    private final Activity activity;
    private final ViewGroup decor;
    private final JoystickConfig cfg = new JoystickConfig();
    private final JoystickDriver driver;
    private final FpsUnlocker fps;
    private final SpinFeature spin;
    private final DodgeFeature dodge;
    private LinearLayout root, panel;
    private TextView status;
    private Switch swFps, swSpin, swDodge;
    private CalibrationOverlay calibration;

    private ModMenu(Activity a, ViewGroup decor) {
        this.activity = a; this.decor = decor;
        cfg.load(a);
        driver = new JoystickDriver(decor);
        fps = new FpsUnlocker(a);
        spin = new SpinFeature(driver, cfg);
        ThreatSource src = pendingSource != null ? pendingSource : new UnconfiguredThreatSource();
        dodge = new DodgeFeature(driver, cfg, src, new Runnable() {
            @Override public void run() {
                swDodge.setChecked(false);
                say(dodge.getSource().unavailableReason());
            }
        });
    }

    private int dp(int v) { return Math.round(v * activity.getResources().getDisplayMetrics().density); }

    private void say(String s) { status.setText(s); }

    private void build() {
        root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);

        TextView button = new TextView(activity);
        button.setText("R");
        button.setTextColor(Color.WHITE);
        button.setGravity(Gravity.CENTER);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(0xCC1565C0);
        button.setBackground(circle);
        root.addView(button, new LinearLayout.LayoutParams(dp(44), dp(44)));

        panel = new LinearLayout(activity);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(8), dp(12), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xE6202124);
        bg.setCornerRadius(dp(10));
        panel.setBackground(bg);
        panel.setVisibility(View.GONE);
        root.addView(panel, new LinearLayout.LayoutParams(dp(230), ViewGroup.LayoutParams.WRAP_CONTENT));

        swFps = addSwitch("FPS unlocker");
        swSpin = addSwitch("Spin");
        TextView speedLabel = label("Spin speed");
        panel.addView(speedLabel);
        SeekBar speed = new SeekBar(activity);
        speed.setMax(15);
        speed.setProgress(5);
        panel.addView(speed);
        swDodge = addSwitch("Auto dodge");
        Button calibrate = new Button(activity);
        calibrate.setText("Calibrate joystick");
        panel.addView(calibrate);
        status = label(cfg.isSet() ? "Joystick calibrated." : "Joystick not calibrated.");
        panel.addView(status);

        swFps.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                if (on) say(fps.enable()); else { fps.disable(); say("FPS request cleared."); }
            }
        });
        swSpin.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                if (!on) { spin.stop(); return; }
                if (!cfg.isSet()) { b.setChecked(false); say("Calibrate the joystick first."); return; }
                swDodge.setChecked(false);
                spin.start();
                say("Spin running.");
            }
        });
        swDodge.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                if (!on) { dodge.stop(); return; }
                if (!cfg.isSet()) { b.setChecked(false); say("Calibrate the joystick first."); return; }
                if (!dodge.getSource().isAvailable()) {
                    b.setChecked(false); say(dodge.getSource().unavailableReason()); return;
                }
                swSpin.setChecked(false);
                dodge.start();
                say("Auto dodge running.");
            }
        });
        speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                spin.setRevsPerSecond(0.25f + 0.25f * p);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        calibrate.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { beginCalibration(); }
        });

        final FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.leftMargin = dp(8);
        lp.topMargin = dp(80);
        decor.addView(root, lp);

        final int slop = dp(8);
        button.setOnTouchListener(new View.OnTouchListener() {
            float downRawX, downRawY; int startLeft, startTop; boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = e.getRawX(); downRawY = e.getRawY();
                        startLeft = lp.leftMargin; startTop = lp.topMargin; moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downRawX, dy = e.getRawY() - downRawY;
                        if (Math.abs(dx) > slop || Math.abs(dy) > slop) moved = true;
                        if (moved) {
                            lp.leftMargin = Math.max(0, Math.round(startLeft + dx));
                            lp.topMargin = Math.max(0, Math.round(startTop + dy));
                            root.setLayoutParams(lp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) panel.setVisibility(panel.getVisibility() == View.GONE ? View.VISIBLE : View.GONE);
                        return true;
                    default: return true;
                }
            }
        });
    }

    private Switch addSwitch(String text) {
        Switch s = new Switch(activity);
        s.setText(text);
        s.setTextColor(Color.WHITE);
        panel.addView(s);
        return s;
    }

    private TextView label(String text) {
        TextView t = new TextView(activity);
        t.setText(text);
        t.setTextColor(0xFFDDDDDD);
        return t;
    }

    private void beginCalibration() {
        swSpin.setChecked(false);
        swDodge.setChecked(false);
        panel.setVisibility(View.GONE);
        root.setVisibility(View.GONE);
        calibration = new CalibrationOverlay(activity, new CalibrationOverlay.Listener() {
            @Override public void onDone(float ax, float ay, float r) {
                cfg.anchorX = ax; cfg.anchorY = ay; cfg.radius = r;
                cfg.save(activity);
                endCalibration("Joystick calibrated (radius " + Math.round(r) + " px).");
            }
            @Override public void onCancel() { endCalibration("Calibration cancelled."); }
        });
        decor.addView(calibration, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void endCalibration(String msg) {
        decor.removeView(calibration);
        calibration = null;
        root.setVisibility(View.VISIBLE);
        panel.setVisibility(View.VISIBLE);
        say(msg);
    }

    private void detach() {
        spin.stop();
        dodge.stop();
        fps.disable();
        if (calibration != null) decor.removeView(calibration);
        if (root != null) decor.removeView(root);
    }
}
