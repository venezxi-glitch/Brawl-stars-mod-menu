package com.ritmada.menu;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/** Entry point: ModMenu.attach(activity) from the game's launcher Activity.onCreate. */
public final class ModMenu {
    static final String TAG = "Ritmada";
    private static final String VERSION = "2";
    private static final String PREFS = "ritmada_menu";
    private static final int COL_TEXT = 0xFFFFFFFF, COL_DIM = 0xFFBDC1C6;
    private static final int COL_OK = 0xFF81C784, COL_WARN = 0xFFFFB74D, COL_ERR = 0xFFE57373;

    private static ModMenu instance;
    private static volatile ThreatSource pendingSource;

    public static void attach(final Activity activity) {
        try {
            final View decor = activity.getWindow().getDecorView();
            decor.post(new Runnable() {
                @Override public void run() {
                    try {
                        if (!(decor instanceof ViewGroup)) return;
                        if (instance != null) {
                            if (instance.activity == activity) return;
                            instance.detach();
                            instance = null;
                        }
                        ModMenu m = new ModMenu(activity, (ViewGroup) decor);
                        m.build();
                        instance = m;
                    } catch (Throwable t) {
                        Safe.fail(activity, "menu failed to start", t);
                    }
                }
            });
        } catch (Throwable t) {
            Safe.fail(activity, "attach failed", t);
        }
    }

    public static void setThreatSource(ThreatSource s) {
        pendingSource = s;
        if (instance != null) instance.dodge.setSource(s);
    }

    private final Activity activity;
    private final ViewGroup decor;
    private final SharedPreferences prefs;
    private final JoystickConfig cfg = new JoystickConfig();
    private final JoystickDriver driver;
    private final FpsUnlocker fps;
    private final SpinFeature spin;
    private final DodgeFeature dodge;
    private LinearLayout root, panel;
    private TextView status, speedLabel;
    private Switch swFps, swSpin, swReverse, swDodge;
    private CalibrationOverlay calibration;

    private ModMenu(Activity a, ViewGroup decor) {
        this.activity = a; this.decor = decor;
        prefs = a.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        cfg.load(a);
        driver = new JoystickDriver(decor);
        fps = new FpsUnlocker(a);
        spin = new SpinFeature(driver, cfg);
        ThreatSource src = pendingSource != null ? pendingSource : new UnconfiguredThreatSource();
        dodge = new DodgeFeature(driver, cfg, src, new Runnable() {
            @Override public void run() {
                swDodge.setChecked(false);
                say(dodge.getSource().unavailableReason(), COL_WARN);
            }
        });
    }

    private int dp(int v) { return Math.round(v * activity.getResources().getDisplayMetrics().density); }

    private void say(String s, int color) { status.setText(s); status.setTextColor(color); }

    private TextView text(String t, int sp, int color, boolean bold) {
        TextView v = new TextView(activity);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private TextView section(String t) {
        TextView v = text(t.toUpperCase(java.util.Locale.ROOT), 11, 0xFF8AB4F8, true);
        v.setPadding(0, dp(10), 0, dp(2));
        return v;
    }

    private Switch addSwitch(String label) {
        Switch s = new Switch(activity);
        s.setText(label);
        s.setTextColor(COL_TEXT);
        s.setPadding(0, dp(4), 0, dp(4));
        panel.addView(s);
        return s;
    }

    private void build() {
        root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);

        TextView button = new TextView(activity);
        button.setText("R");
        button.setTextSize(16);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setTextColor(Color.WHITE);
        button.setGravity(Gravity.CENTER);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(0xCC1565C0);
        button.setBackground(circle);
        root.addView(button, new LinearLayout.LayoutParams(dp(44), dp(44)));

        panel = new LinearLayout(activity);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(10), dp(14), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF2202124);
        bg.setCornerRadius(dp(12));
        panel.setBackground(bg);
        panel.setVisibility(View.GONE);
        root.addView(panel, new LinearLayout.LayoutParams(dp(240), ViewGroup.LayoutParams.WRAP_CONTENT));

        panel.addView(text("Ritmada menu  v" + VERSION, 15, COL_TEXT, true));

        panel.addView(section("Display"));
        swFps = addSwitch("FPS unlocker");

        panel.addView(section("Joystick"));
        Button calibrate = new Button(activity);
        calibrate.setText("Calibrate joystick");
        calibrate.setAllCaps(false);
        panel.addView(calibrate);
        swSpin = addSwitch("Spin");
        swReverse = addSwitch("Reverse spin direction");
        speedLabel = text("Spin speed: 1.5 rev/s", 12, COL_DIM, false);
        panel.addView(speedLabel);
        SeekBar speed = new SeekBar(activity);
        speed.setMax(15);
        speed.setProgress(5);
        panel.addView(speed);

        panel.addView(section("Combat"));
        swDodge = addSwitch("Auto dodge");

        status = text(cfg.isSet() ? "Joystick calibrated." : "Joystick not calibrated.", 12,
            cfg.isSet() ? COL_OK : COL_WARN, false);
        status.setPadding(0, dp(10), 0, 0);
        panel.addView(status);

        spin.setOnFault(new Runnable() {
            @Override public void run() {
                swSpin.setChecked(false);
                say("Spin stopped after an error. See logcat tag Ritmada.", COL_ERR);
            }
        });

        swFps.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                try {
                    if (on) say(fps.enable(), COL_OK);
                    else { fps.disable(); say("FPS request cleared.", COL_DIM); }
                } catch (Throwable t) {
                    Safe.log("fps", t);
                    b.setChecked(false);
                    say("FPS unlock failed: " + t.getClass().getSimpleName(), COL_ERR);
                }
            }
        });
        swSpin.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                if (!on) { spin.stop(); return; }
                if (!cfg.isSet()) { b.setChecked(false); say("Calibrate the joystick first.", COL_WARN); return; }
                swDodge.setChecked(false);
                spin.start();
                say("Spin running.", COL_OK);
            }
        });
        swReverse.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) { spin.setReverse(on); }
        });
        swDodge.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                if (!on) { dodge.stop(); return; }
                if (!cfg.isSet()) { b.setChecked(false); say("Calibrate the joystick first.", COL_WARN); return; }
                if (!dodge.getSource().isAvailable()) {
                    b.setChecked(false); say(dodge.getSource().unavailableReason(), COL_WARN); return;
                }
                swSpin.setChecked(false);
                dodge.start();
                say("Auto dodge running.", COL_OK);
            }
        });
        speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                float revs = 0.25f + 0.25f * p;
                spin.setRevsPerSecond(revs);
                speedLabel.setText("Spin speed: " + (Math.round(revs * 100) / 100f) + " rev/s");
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        calibrate.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { beginCalibration(); }
        });

        final FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.leftMargin = clampX(prefs.getInt("mx", dp(8)));
        lp.topMargin = clampY(prefs.getInt("my", dp(80)));
        decor.addView(root, lp);

        final int slop = dp(8);
        button.setOnTouchListener(new View.OnTouchListener() {
            float downRawX, downRawY; int startLeft, startTop; boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = e.getRawX(); downRawY = e.getRawY();
                        startLeft = lp.leftMargin; startTop = lp.topMargin; moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downRawX, dy = e.getRawY() - downRawY;
                        if (Math.abs(dx) > slop || Math.abs(dy) > slop) moved = true;
                        if (moved) {
                            lp.leftMargin = clampX(Math.round(startLeft + dx));
                            lp.topMargin = clampY(Math.round(startTop + dy));
                            root.setLayoutParams(lp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (moved) prefs.edit().putInt("mx", lp.leftMargin).putInt("my", lp.topMargin).apply();
                        else panel.setVisibility(panel.getVisibility() == View.GONE ? View.VISIBLE : View.GONE);
                        return true;
                    default: return true;
                }
            }
        });
    }

    private int clampX(int x) {
        int max = decor.getWidth() > 0 ? decor.getWidth() - dp(44) : Integer.MAX_VALUE;
        return Math.max(0, Math.min(x, max));
    }

    private int clampY(int y) {
        int max = decor.getHeight() > 0 ? decor.getHeight() - dp(44) : Integer.MAX_VALUE;
        return Math.max(0, Math.min(y, max));
    }

    private void beginCalibration() {
        swSpin.setChecked(false);
        swDodge.setChecked(false);
        panel.setVisibility(View.GONE);
        root.setVisibility(View.GONE);
        calibration = new CalibrationOverlay(activity, new CalibrationOverlay.Listener() {
            @Override public void onDone(float ax, float ay, float r) {
                cfg.anchorX = ax; cfg.anchorY = ay; cfg.radius = r;
                cfg.save(activity);
                endCalibration("Joystick calibrated (radius " + Math.round(r) + " px).", COL_OK);
            }
            @Override public void onCancel() { endCalibration("Calibration cancelled.", COL_WARN); }
        });
        decor.addView(calibration, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void endCalibration(String msg, int color) {
        decor.removeView(calibration);
        calibration = null;
        root.setVisibility(View.VISIBLE);
        panel.setVisibility(View.VISIBLE);
        say(msg, color);
    }

    private void detach() {
        try {
            spin.stop();
            dodge.stop();
            fps.disable();
            if (calibration != null) decor.removeView(calibration);
            if (root != null) decor.removeView(root);
        } catch (Throwable t) { Safe.log("detach", t); }
    }
}
