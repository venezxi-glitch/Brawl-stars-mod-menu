package com.ritmada.menu;

/** Pure geometry helpers. No Android dependencies. Screen space: x right, y down, radians. */
final class JoystickMath {
    private JoystickMath() {}

    static float[] pointOnCircle(float cx, float cy, float r, double angleRad) {
        return new float[] {
            (float) (cx + r * Math.cos(angleRad)),
            (float) (cy + r * Math.sin(angleRad))
        };
    }
}
