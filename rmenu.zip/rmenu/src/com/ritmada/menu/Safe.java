package com.ritmada.menu;

import android.app.Activity;
import android.util.Log;
import android.widget.Toast;

/** Menu failures must never take the game down: log them and show a short on-screen note. */
final class Safe {
    private Safe() {}

    static void log(String msg, Throwable t) { Log.e(ModMenu.TAG, msg, t); }

    static void toast(final Activity a, final String msg) {
        try {
            a.runOnUiThread(new Runnable() {
                @Override public void run() { Toast.makeText(a, msg, Toast.LENGTH_LONG).show(); }
            });
        } catch (Throwable ignored) { }
    }

    static void fail(Activity a, String what, Throwable t) {
        log(what, t);
        toast(a, "Ritmada: " + what + " (" + t.getClass().getSimpleName() + ")");
    }
}
