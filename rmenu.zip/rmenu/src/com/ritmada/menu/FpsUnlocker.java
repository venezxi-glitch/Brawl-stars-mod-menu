package com.ritmada.menu;

import android.app.Activity;
import android.os.Build;
import android.view.Display;
import android.view.Surface;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;

/**
 * Requests the display's highest refresh rate at the current resolution, and on API 30+ also
 * hints the game's SurfaceView. This does not touch the game's own native frame limiter.
 */
final class FpsUnlocker {
    private final Activity activity;

    FpsUnlocker(Activity a) { activity = a; }

    String enable() {
        if (Build.VERSION.SDK_INT < 23) return "FPS unlock needs Android 6.0 or newer.";
        Window w = activity.getWindow();
        Display display = activity.getWindowManager().getDefaultDisplay();
        Display.Mode cur = display.getMode();
        Display.Mode best = cur;
        for (Display.Mode m : display.getSupportedModes()) {
            if (m.getPhysicalWidth() == cur.getPhysicalWidth()
                    && m.getPhysicalHeight() == cur.getPhysicalHeight()
                    && m.getRefreshRate() > best.getRefreshRate()) best = m;
        }
        WindowManager.LayoutParams lp = w.getAttributes();
        lp.preferredDisplayModeId = best.getModeId();
        w.setAttributes(lp);
        String hint = "no SurfaceView found";
        if (Build.VERSION.SDK_INT >= 30) {
            SurfaceView sv = findSurfaceView(w.getDecorView());
            if (sv != null && sv.getHolder().getSurface().isValid()) {
                sv.getHolder().getSurface().setFrameRate(best.getRefreshRate(), Surface.FRAME_RATE_COMPATIBILITY_DEFAULT);
                hint = "surface hint set";
            }
        }
        if (best.getRefreshRate() <= cur.getRefreshRate() + 0.5f)
            return "Display offers no higher mode than " + Math.round(cur.getRefreshRate()) + " Hz.";
        return "Requested " + Math.round(best.getRefreshRate()) + " Hz (" + hint + ").";
    }

    void disable() {
        if (Build.VERSION.SDK_INT < 23) return;
        Window w = activity.getWindow();
        WindowManager.LayoutParams lp = w.getAttributes();
        lp.preferredDisplayModeId = 0;
        w.setAttributes(lp);
        if (Build.VERSION.SDK_INT >= 30) {
            SurfaceView sv = findSurfaceView(w.getDecorView());
            if (sv != null && sv.getHolder().getSurface().isValid())
                sv.getHolder().getSurface().setFrameRate(0f, Surface.FRAME_RATE_COMPATIBILITY_DEFAULT);
        }
    }

    private static SurfaceView findSurfaceView(View v) {
        if (v instanceof SurfaceView) return (SurfaceView) v;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                SurfaceView r = findSurfaceView(g.getChildAt(i));
                if (r != null) return r;
            }
        }
        return null;
    }
}
