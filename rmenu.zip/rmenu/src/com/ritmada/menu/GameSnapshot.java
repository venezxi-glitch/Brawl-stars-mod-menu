package com.ritmada.menu;

import java.util.List;

/**
 * One frame of game state in SCREEN-ALIGNED axes (x right, y down). Units are arbitrary
 * but must be identical for positions, velocities (units per second) and radii.
 * The ThreatSource implementation is responsible for converting game world axes to this.
 */
final class GameSnapshot {
    static final class Threat {
        final float x, y, vx, vy, radius;
        Threat(float x, float y, float vx, float vy, float radius) {
            this.x = x; this.y = y; this.vx = vx; this.vy = vy; this.radius = radius;
        }
    }

    final float playerX, playerY, playerRadius;
    final List<Threat> threats;

    GameSnapshot(float playerX, float playerY, float playerRadius, List<Threat> threats) {
        this.playerX = playerX; this.playerY = playerY;
        this.playerRadius = playerRadius; this.threats = threats;
    }
}
