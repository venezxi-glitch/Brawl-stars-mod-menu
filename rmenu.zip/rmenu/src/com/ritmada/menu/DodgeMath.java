package com.ritmada.menu;

/** Pure dodge decision logic. No Android dependencies, checkable without the game. */
final class DodgeMath {
    private DodgeMath() {}

    private static boolean finite(float... v) {
        for (float f : v) if (Float.isNaN(f) || Float.isInfinite(f)) return false;
        return true;
    }

    /**
     * Returns a unit direction (screen axes, y down) that moves the player off the predicted
     * paths of threats, or null when nothing needs dodging.
     * Each threat is a moving circle on a straight line. We find its closest approach to the
     * player within horizonSec; if that is inside (threatRadius + playerRadius) * (1 + marginRatio),
     * we push perpendicular to the threat's velocity, toward the side the player is already on,
     * weighted by overlap depth and by how soon the approach happens.
     */
    static float[] dodgeDirection(GameSnapshot s, float horizonSec, float marginRatio) {
        if (s == null || !finite(s.playerX, s.playerY, s.playerRadius)) return null;
        double sx = 0, sy = 0;
        for (GameSnapshot.Threat t : s.threats) {
            if (!finite(t.x, t.y, t.vx, t.vy, t.radius)) continue;
            double dx = t.x - s.playerX, dy = t.y - s.playerY;
            double clearance = (t.radius + s.playerRadius) * (1.0 + marginRatio);
            if (clearance <= 0) continue;
            double v2 = (double) t.vx * t.vx + (double) t.vy * t.vy;
            if (v2 < 1e-9) {
                double dist = Math.hypot(dx, dy);
                if (dist >= clearance || dist < 1e-6) continue;
                double w = (clearance - dist) / clearance;
                sx += -dx / dist * w;
                sy += -dy / dist * w;
                continue;
            }
            double tc = -(dx * t.vx + dy * t.vy) / v2;
            tc = Math.max(0.0, Math.min(horizonSec, tc));
            double cx = dx + t.vx * tc, cy = dy + t.vy * tc;
            double dist = Math.hypot(cx, cy);
            if (dist >= clearance) continue;
            double inv = 1.0 / Math.sqrt(v2);
            double px = -t.vy * inv, py = t.vx * inv;
            double side = px * (-cx) + py * (-cy);
            double sign = side >= 0 ? 1.0 : -1.0;
            double w = ((clearance - dist) / clearance) / (tc + 0.1);
            sx += px * sign * w;
            sy += py * sign * w;
        }
        double m = Math.hypot(sx, sy);
        if (m < 1e-6) return null;
        return new float[] {(float) (sx / m), (float) (sy / m)};
    }
}
