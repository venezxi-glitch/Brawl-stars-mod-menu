package com.ritmada.menu;

import android.view.Choreographer;

/** Per-frame: read threats from the ThreatSource, steer the joystick away from them. Main thread only. */
final class DodgeFeature implements Choreographer.FrameCallback {
    private static final float TILT = 0.95f;
    private static final float HORIZON_SECONDS = 0.6f; // uncalibrated
    private static final float MARGIN_RATIO = 0.25f;   // uncalibrated

    private final JoystickDriver driver;
    private final JoystickConfig cfg;
    private final Runnable onUnavailable;
    private volatile ThreatSource source;
    private boolean running;

    DodgeFeature(JoystickDriver d, JoystickConfig c, ThreatSource s, Runnable onUnavailable) {
        driver = d; cfg = c; source = s; this.onUnavailable = onUnavailable;
    }

    void setSource(ThreatSource s) { source = s; }
    ThreatSource getSource() { return source; }
    boolean isRunning() { return running; }

    boolean start() {
        if (running) return true;
        ThreatSource s = source;
        if (!cfg.isSet() || s == null || !s.isAvailable()) return false;
        running = true;
        Choreographer.getInstance().postFrameCallback(this);
        return true;
    }

    void stop() {
        if (!running) return;
        running = false;
        Choreographer.getInstance().removeFrameCallback(this);
        driver.release();
    }

    @Override public void doFrame(long frameTimeNanos) {
        if (!running) return;
        ThreatSource s = source;
        if (s == null || !s.isAvailable()) { stop(); onUnavailable.run(); return; }
        float[] dir = DodgeMath.dodgeDirection(s.poll(), HORIZON_SECONDS, MARGIN_RATIO);
        if (dir == null) {
            driver.release();
        } else {
            if (!driver.isDown()) driver.press(cfg.anchorX, cfg.anchorY);
            driver.moveTo(cfg.anchorX + dir[0] * cfg.radius * TILT, cfg.anchorY + dir[1] * cfg.radius * TILT);
        }
        Choreographer.getInstance().postFrameCallback(this);
    }
}
