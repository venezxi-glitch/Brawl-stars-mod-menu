package com.ritmada.menu;

/** Supplies game state to Auto Dodge. Implementations read it from the game by whatever means you choose. */
public interface ThreatSource {
    boolean isAvailable();
    String unavailableReason();
    /** Called once per frame on the main thread. Return null if the state is invalid this frame. */
    GameSnapshot poll();
}
