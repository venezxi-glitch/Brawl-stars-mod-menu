package com.ritmada.menu;

import android.os.SystemClock;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.View;

/** Feeds one synthetic touch stream to the target view. Main thread only. */
final class JoystickDriver {
    private final View target;
    private long downTime;
    private boolean down;
    private float lastX, lastY;

    JoystickDriver(View target) { this.target = target; }

    boolean isDown() { return down; }

    void press(float x, float y) {
        if (down) return;
        downTime = SystemClock.uptimeMillis();
        lastX = x; lastY = y;
        send(MotionEvent.ACTION_DOWN, x, y);
        down = true;
    }

    void moveTo(float x, float y) {
        if (!down) return;
        lastX = x; lastY = y;
        send(MotionEvent.ACTION_MOVE, x, y);
    }

    void release() {
        if (!down) return;
        down = false;
        send(MotionEvent.ACTION_UP, lastX, lastY);
    }

    private void send(int action, float x, float y) {
        MotionEvent ev = MotionEvent.obtain(downTime, SystemClock.uptimeMillis(), action, x, y, 0);
        ev.setSource(InputDevice.SOURCE_TOUCHSCREEN);
        try { target.dispatchTouchEvent(ev); } finally { ev.recycle(); }
    }
}
