package com.ritmada.menu;

import android.view.Choreographer;

/** Drives the joystick around a circle in a loop while enabled. Main thread only. */
final class SpinFeature implements Choreographer.FrameCallback {
    private static final float TILT = 0.9f; // fraction of calibrated radius

    private final JoystickDriver driver;
    private final JoystickConfig cfg;
    private volatile float revsPerSecond = 1.5f; // uncalibrated starting value
    private boolean running;
    private long lastNanos;
    private double angle;

    SpinFeature(JoystickDriver d, JoystickConfig c) { driver = d; cfg = c; }

    void setRevsPerSecond(float v) { revsPerSecond = v; }
    boolean isRunning() { return running; }

    boolean start() {
        if (running) return true;
        if (!cfg.isSet()) return false;
        running = true; lastNanos = 0; angle = 0;
        Choreographer.getInstance().postFrameCallback(this);
        return true;
    }

    void stop() {
        if (!running) return;
        running = false;
        Choreographer.getInstance().removeFrameCallback(this);
        driver.release();
    }

    @Override public void doFrame(long frameTimeNanos) {
        if (!running) return;
        if (lastNanos != 0) angle += 2.0 * Math.PI * revsPerSecond * (frameTimeNanos - lastNanos) / 1e9;
        lastNanos = frameTimeNanos;
        if (!driver.isDown()) driver.press(cfg.anchorX, cfg.anchorY);
        float[] p = JoystickMath.pointOnCircle(cfg.anchorX, cfg.anchorY, cfg.radius * TILT, angle);
        driver.moveTo(p[0], p[1]);
        Choreographer.getInstance().postFrameCallback(this);
    }
}
