#!/usr/bin/env bash
# Usage: ANDROID_HOME=/path/to/sdk BUILD_TOOLS=34.0.0 PLATFORM=android-34 ./build.sh
set -euo pipefail
: "${ANDROID_HOME:?set ANDROID_HOME}"; : "${BUILD_TOOLS:?set BUILD_TOOLS}"; : "${PLATFORM:?set PLATFORM}"
JAR="$ANDROID_HOME/platforms/$PLATFORM/android.jar"
rm -rf out && mkdir -p out/classes out/dex out/test
# 1) Pure-logic check (no Android needed): compiles and runs MathCheck
javac -d out/test src/com/ritmada/menu/{JoystickMath,GameSnapshot,DodgeMath}.java test/MathCheck.java
java -cp out/test com.ritmada.menu.MathCheck
# 2) Android classes -> classes.dex
javac -source 8 -target 8 -cp "$JAR" -d out/classes $(find src -name '*.java')
"$ANDROID_HOME/build-tools/$BUILD_TOOLS/d8" --lib "$JAR" --min-api 23 --output out/dex $(find out/classes -name '*.class')
echo "Built out/dex/classes.dex"
